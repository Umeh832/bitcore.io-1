export interface HostPort {
  host: string;
  port: number;
}
