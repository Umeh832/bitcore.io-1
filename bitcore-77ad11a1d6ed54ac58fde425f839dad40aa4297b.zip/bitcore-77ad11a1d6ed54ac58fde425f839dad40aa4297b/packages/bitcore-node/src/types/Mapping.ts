interface Mapping<V> {
  [key: string]: V;
}
