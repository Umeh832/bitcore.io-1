export interface TransformOptions {
  object: boolean;
}
