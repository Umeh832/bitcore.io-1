export interface UserPassword {
  username: string;
  password: string;
}
